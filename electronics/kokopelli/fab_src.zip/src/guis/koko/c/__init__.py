""" Module defining C data structures from the libfab library. """
