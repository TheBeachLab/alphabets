TEMPLATE = '''from koko.lib.shapes import *

cad.function = circle(0, 0, 0.5)
'''
