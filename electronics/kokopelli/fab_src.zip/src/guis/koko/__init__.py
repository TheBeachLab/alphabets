""" Top-level module for kokopelli. """

NAME = 'kokopelli'
VERSION = '0.2'
CHANGESET = ':'

"""
@namespace koko
@brief Top-level module
"""
