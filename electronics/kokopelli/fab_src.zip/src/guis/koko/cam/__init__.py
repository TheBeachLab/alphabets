"""
@namespace cam
@brief Module containing CAM-related functionality
"""
