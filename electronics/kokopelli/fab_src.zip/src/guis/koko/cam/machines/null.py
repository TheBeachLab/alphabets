# Empty machine description file

NAME = "<None>"
INPUT = None
PANEL = None
DEFAULTS = {}
