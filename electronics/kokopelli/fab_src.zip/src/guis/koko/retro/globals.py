# weakref.proxy references to various globals live here.
FRAME   = None
APP     = None
CANVAS  = None
SHAPES  = None
EDITOR  = None
