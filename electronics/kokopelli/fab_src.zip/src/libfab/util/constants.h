#ifndef UTIL_CONSTANTS_H
#define UTIL_CONSTANTS_H

#define EPSILON 1e-6

#endif

